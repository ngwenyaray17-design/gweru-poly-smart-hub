Infra & Deployment Notes
------------------------
- You can deploy the frontend to Vercel (free) and backend to Render (free) for prototyping.
- Keep secrets in GitHub Actions / Vercel / Render environment variables.
- For Paynow/EcoCash live, complete merchant onboarding and use production keys.
