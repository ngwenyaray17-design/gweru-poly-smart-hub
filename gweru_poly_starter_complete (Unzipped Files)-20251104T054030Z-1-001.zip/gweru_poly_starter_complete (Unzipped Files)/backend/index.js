require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const pool = new Pool({ connectionString: process.env.DATABASE_URL || 'postgres://gweru:gweru_pass@localhost:5432/gweru_poly' });

const app = express();
app.use(cors());
app.use(bodyParser.json());

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

async function findUserByEmail(email){
  const res = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  return res.rows[0];
}

function generateToken(user){
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '7d' });
}

function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if(!auth) return res.status(401).json({ error: 'Missing authorization' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch(e){
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Routes
app.post('/api/v1/auth/register', async (req,res) => {
  const { email, password, display_name, role } = req.body;
  if(!email || !password || !role) return res.status(400).json({ error: 'Missing fields' });
  const existing = await findUserByEmail(email);
  if(existing) return res.status(400).json({ error: 'Email exists' });
  const pwHash = await bcrypt.hash(password, 10);
  const id = uuidv4();
  await pool.query('INSERT INTO users (id,email,display_name,password_hash,role,is_verified,created_at) VALUES ($1,$2,$3,$4,$5,true,now())', [id,email,display_name,pwHash,role]);
  const user = await findUserByEmail(email);
  const token = generateToken(user);
  res.json({ user: { id: user.id, email: user.email, display_name: user.display_name, role: user.role }, token });
});

app.post('/api/v1/auth/login', async (req,res) => {
  const { email, password } = req.body;
  const user = await findUserByEmail(email);
  if(!user) return res.status(400).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if(!ok) return res.status(400).json({ error: 'Invalid credentials' });
  const token = generateToken(user);
  res.json({ user: { id: user.id, email: user.email, display_name: user.display_name, role: user.role }, token });
});

app.get('/api/v1/dashboard', authMiddleware, async (req,res) => {
  const { role } = req.user;
  if(role === 'creator') {
    const usersCount = (await pool.query('SELECT COUNT(*) FROM users')).rows[0].count;
    return res.json({ message: 'Creator dashboard', usersCount });
  }
  if(role === 'institution_admin') {
    return res.json({ message: 'Institution admin dashboard' });
  }
  return res.json({ message: 'Student dashboard' });
});

// Content listing
app.get('/api/v1/content', authMiddleware, async (req,res) => {
  const rows = (await pool.query('SELECT id,title,description,file_url,content_type FROM content ORDER BY created_at DESC LIMIT 50')).rows;
  res.json({ items: rows });
});

// Payments - Paynow mock create and webhook
app.post('/api/v1/payments/paynow/create', authMiddleware, async (req,res) => {
  const { amount_cents, currency } = req.body;
  const checkout_url = `https://sandbox.paynow.mock/checkout?ref=${Date.now()}`;
  const reference = `GWERU-${Date.now()}`;
  // In production you would persist a pending payment record
  res.json({ checkout_url, reference });
});

app.post('/api/v1/payments/paynow/webhook', async (req,res) => {
  console.log('Paynow webhook received', req.body);
  res.json({ status: 'ok' });
});

// EcoCash mock endpoints
app.post('/api/v1/payments/ecocash/create', authMiddleware, async (req,res) => {
  const { amount_cents } = req.body;
  const reference = `ECO-${Date.now()}`;
  res.json({ provider: 'ecocash', reference, status: 'sandbox' });
});

// Sync endpoint placeholder
app.post('/api/v1/sync/push', authMiddleware, async (req,res) => {
  const { device_id, changes } = req.body;
  await pool.query('INSERT INTO device_sync_logs (device_id, user_id, payload, synced, created_at) VALUES ($1,$2,$3,false,now())', [device_id, req.user.id, JSON.stringify(changes)]);
  res.json({ status: 'queued' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Backend listening on ${PORT}`));
