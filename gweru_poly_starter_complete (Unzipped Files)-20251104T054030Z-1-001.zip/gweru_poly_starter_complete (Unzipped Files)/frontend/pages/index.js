import Link from 'next/link';
export default function Home(){ return (<div style={{padding:40,fontFamily:'Arial'}}><h1>Gweru Poly Smart Hub</h1><p><Link href='/auth/login'>Login</Link></p></div>); }
